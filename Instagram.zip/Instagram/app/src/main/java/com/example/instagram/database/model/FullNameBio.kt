package com.example.instagram.database.model

data class FullNameBio(
    val first_name: String,
    val last_name: String,
    val bio: String,
)
