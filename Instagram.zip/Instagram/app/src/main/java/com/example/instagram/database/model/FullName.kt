package com.example.instagram.database.model

data class FullName(
    var first_name: String,
    var last_name: String
)
