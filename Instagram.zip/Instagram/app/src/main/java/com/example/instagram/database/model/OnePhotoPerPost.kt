package com.example.instagram.database.model

data class OnePhotoPerPost(
    val postId: Long,
    val imageURl: String,
)
